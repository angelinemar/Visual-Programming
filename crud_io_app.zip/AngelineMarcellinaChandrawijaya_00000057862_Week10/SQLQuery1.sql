CREATE DATABASE universitas;
CREATE TABLE datadosen (
kddosen varchar(50),
nama varchar(50),
alamat varchar(50),
telp varchar(50),
hp varchar(50)
primary key (kddosen)
)

SELECT * FROM datadosen;

DROP TABLE datadosen;