﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string constring = "Data Source=LAPTOP-1S988UHA\\SQLEXPRESS01;Initial Catalog=universitas;Integrated Security=True";
        DataSet DS = new DataSet();
        string vquery = "";
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "")
            {

                string query = "insert into datadosen (kddosen,nama,alamat,telp,hp) values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "')";
                SqlConnection conn = new SqlConnection(constring);
                SqlDataAdapter DA = new SqlDataAdapter(query, conn);
                DA.Fill(DS, "universitas");
                MessageBox.Show("Data Berhasil Diinput");
            }
            else
            {
                MessageBox.Show("Data Gagal Diinput");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox4.Text != "" && textBox5.Text != "")
            {
                string query = "update datadosen set nama='" + textBox2.Text + "', alamat='" + textBox3.Text + "', telp='" + textBox4.Text + "', hp='" + textBox5.Text + "' where kddosen='" + textBox1.Text + "'";
                SqlConnection conn = new SqlConnection(constring);
                SqlDataAdapter DA = new SqlDataAdapter(query, conn);
                DA.Fill(DS, "universitas");
                MessageBox.Show("Data Berhasil Di Update");
            }
            else
            {
                MessageBox.Show("Data Gagal Di Update");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                string query = "delete from datadosen where kddosen='" + textBox1.Text + "'";
                SqlConnection conn = new SqlConnection(constring);
                SqlDataAdapter DA = new SqlDataAdapter(query, conn);
                DA.Fill(DS, "universitas");
                MessageBox.Show("Data Berhasil Di Delete");
            }
            else
            {
                MessageBox.Show("Data Gagal Di Delete");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection(constring);
            SqlCommand views = new SqlCommand("select * from datadosen where kddosen = @kddosen", con);
            views.Parameters.AddWithValue("@kddosen", textBox1.Text);

            try
            {
                var dt = new DataTable();
                con.Open();
                SqlDataReader read = views.ExecuteReader();
                dt.Load(read);

                Form2 viewForm2 = new Form2(dt);
                viewForm2.Show();

            }
            catch
            {
                MessageBox.Show("cannot open connection!");
            }
            finally
            {
                con.Close();
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
