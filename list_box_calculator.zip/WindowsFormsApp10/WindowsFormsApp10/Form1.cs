﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp10
{
    public partial class Form1 : Form
    {
        public String histo;
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int i;
            string message;
            string temp = null;
            float jumlah = 0;
            int indeks = 1;
            double grade;
            int input = Convert.ToInt32(textBox1.Text);
            int[] varray = new int[input];
            for (i = 0; i < input; i++)
            {
                varray[i] = Convert.ToInt32(Interaction.InputBox(message = "Masukan Nilai Elemen Array " + indeks));
                jumlah = jumlah + varray[i];
                temp += indeks + "  Nilainya  " + varray[i] + Environment.NewLine;
                grade = jumlah / input;
                textBox2.Text = Convert.ToString(temp);
                label4.Text = Convert.ToString(jumlah);

                hitung nilai = new hitung();
                label5.Text = nilai.nilaiHuruf(grade);
                indeks++;

            }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
