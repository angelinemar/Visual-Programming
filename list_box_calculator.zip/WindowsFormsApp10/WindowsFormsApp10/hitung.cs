﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp10
{
    internal class hitung
    {
        public double grade;

        public string nilaiHuruf(double grade)
        {
            if (grade >= 85 && grade <= 100)
            {
                return "A";
            }
            else if (grade >= 75 && grade <= 84)
            {
                return "B";
            }
            else if (grade >= 65 && grade <= 74)
            {
                return "C";
            }
            else
            {
                return "D";
            }
        }
    }
}
