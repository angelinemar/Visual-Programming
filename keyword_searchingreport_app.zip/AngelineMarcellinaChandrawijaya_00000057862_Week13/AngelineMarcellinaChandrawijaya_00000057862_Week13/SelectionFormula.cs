﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabWeek13
{
    public partial class SelectionFormula : Form
    {
        string gender;
        DateTime awal;
        DateTime akhir;

        public string Gender
        {
            get { return gender; }
            set { gender = value; }
        }

        public DateTime Awal
        {
            get { return awal; }
            set { awal = value; }
        }

        public DateTime Akhir
        {
            get { return akhir; }
            set { akhir = value; }
        }

        public SelectionFormula()
        {
            InitializeComponent();
        }

        public SelectionFormula(string a, DateTime b, DateTime c)
        {
            InitializeComponent();
            Gender = a;
            Awal = b;
            Akhir = c;
        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {
            string range = "{anggota.ulang_tahun} >=#" + Awal + "#" +
	            "and {anggota.ulang_tahun} <= #" + Akhir + "#";

            string jk = "{anggota.jenis_kelamin} = '" + Gender + "'";

            CrystalReport1 vcr = new CrystalReport1();
            crystalReportViewer1.SelectionFormula = range;
            crystalReportViewer1.SelectionFormula = jk;
            crystalReportViewer1.ReportSource = vcr;
        }
    }
}
