﻿using CrystalDecisions.Shared;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabWeek13
{
    public partial class Param : Form
    {
        string gender;
        DateTime awal;
        DateTime akhir;

        public string Gender
        {
            get { return gender; }
            set { gender = value; }
        }

        public DateTime Awal
        {
            get { return awal; }
            set { awal = value; }
        }

        public DateTime Akhir
        {
            get { return akhir; }
            set { akhir = value; }
        }

        public Param()
        {
            InitializeComponent();
        }

        public Param(string a, DateTime b, DateTime c)
        {
            InitializeComponent();
            Gender = a;
            Awal = b;
            Akhir = c;
        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {
            CrystalReport1 vcr = new CrystalReport1();
            vcr.SetParameterValue("P_JenisKelamin", Gender);

            ParameterRangeValue range = new ParameterRangeValue();
            range.StartValue = Awal;
            range.EndValue = Akhir;

            vcr.SetParameterValue("P_Tanggal", range);
            crystalReportViewer1.ReportSource = vcr;
        }
    }
}
