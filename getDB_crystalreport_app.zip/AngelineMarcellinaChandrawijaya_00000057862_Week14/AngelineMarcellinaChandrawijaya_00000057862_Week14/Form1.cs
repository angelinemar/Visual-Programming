﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AngelineMarcellinaChandrawijaya_00000057862_Week14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string constring = @"Data Source=LAPTOP-1S988UHA\SQLEXPRESS01;Initial Catalog=VISPROGW14;Integrated Security=True";
        DataSet DS = new DataSet();
        string vquery = "";

        //NAMPILIN GRID VIEW
        void tampil()
        {
            SqlConnection conn = new SqlConnection(constring);
            conn.Open();
            DS.Clear();
            vquery = "select * from pelanggan";
            SqlDataAdapter DA = new SqlDataAdapter(vquery, conn);
            DA.Fill(DS, "universitas");
            dataGridView1.DataSource = DS.Tables["universitas"];
            conn.Close();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            string constring = @"Data Source=LAPTOP-1S988UHA\SQLEXPRESS01;Initial Catalog=VISPROGW14;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);

            if (textBox1.Text != "" && textBox1.Text != "" && textBox2.Text != "")
            {

                string query = "insert into pelanggan (id_pelanggan, nama_pelanggan) values('" + textBox1.Text + "','" + textBox2.Text + "' )";
                SqlConnection conn = new SqlConnection(constring);
                SqlDataAdapter DA = new SqlDataAdapter(query, conn);
                DA.Fill(DS, "universitas");
                MessageBox.Show("Data Berhasil Diinput");
                Form2 frm = new Form2();
                frm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Data Gagal Diinput");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            tampil();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
