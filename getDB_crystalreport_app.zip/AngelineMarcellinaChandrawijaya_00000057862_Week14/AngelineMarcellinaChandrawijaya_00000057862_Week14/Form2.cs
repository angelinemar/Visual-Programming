﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Text;

namespace AngelineMarcellinaChandrawijaya_00000057862_Week14
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        string constring = @"Data Source=LAPTOP-1S988UHA\SQLEXPRESS01;Initial Catalog=VISPROGW14;Integrated Security=True";
        DataSet DS = new DataSet();
        string vquery = "";

       

        //static void tulis (string kata)
        //{
        //    FileStream fs = new FileStream("C:\\tes\\pelanggan.txt", FileMode.Append, FileAccess.Write, FileShare.ReadWrite);
        //    StreamWriter sw = new StreamWriter(fs);
        //    sw.WriteLine(kata);
        //    sw.Close();
        //    fs.Close();
        //}


        //static void tuliss(string week14)
        //{

        //}
        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(constring);
            conn.Open();
            DS.Clear();
            vquery = "select * from pelanggan";
            SqlDataAdapter DA = new SqlDataAdapter(vquery, conn);
            DA.Fill(DS, "universitas");
            dataGridView1.DataSource = DS.Tables["universitas"];
            conn.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            TextWriter writer = new StreamWriter(@"C:\Txt\pelanggan.txt");
            for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
            {
                for (int j = 0; j < dataGridView1.Columns.Count; j++)
                {
                    writer.WriteLine("\t" + dataGridView1.Rows[i].Cells[j].Value.ToString() + "\t" + "|");

                }
                writer.WriteLine("");
                writer.WriteLine("------------------------------------------------------------------------");

            }
            writer.Close();
            MessageBox.Show("Data Txt berhasil dibuat");
        }
    }
}
