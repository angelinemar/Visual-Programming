CREATE TABLE pelanggan
(

id_pelanggan VARCHAR(100),
nama_pelanggan VARCHAR(100)

)


SELECT * FROM pelanggan

DROP TABLE pelanggan
------------------------------------------


CREATE TABLE pemasok
(

id_pemasok VARCHAR,
nama_pemasok VARCHAR

)

SELECT * FROM pelanggan